
/**
 * The Menu Class is the basic structure for the menu object. Each menu item is a food item that has a name,
 * description, price and id.
 * @author Liz Jones
 * @version 1.0
 */
// import javafx.fxml.FXML;
// import java.util.objects;
// import javafx.fxml.FXMLLoader;
// import javafx.scene.Node;
// import javafx.scene.Parent;
// import javafx.scene.control.Button;
// import javafx.scene.control.Label;
import java.io.IOException;

public class Menu {
	private String item;
	private String description;
	private double price;
	private int id;

	public Menu() {
	}

	public Menu(String item, double price, int id, String description) {
		this.item = item;
		this.price = price;
		this.id = id;
		this.description = description;
	}

	public int getId() {
		return id;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String toString() {
		return String.format("%S%n%s%n%.2f%n%n", item, description, price);
	}
}
